
import React from 'react';

function Dashboard() {
  return (
    <div>
      <h2>Welcome to DocSpot Dashboard</h2>
    </div>
  );
}

export default Dashboard;
