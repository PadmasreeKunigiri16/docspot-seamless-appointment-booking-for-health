
import React, { useState } from 'react';
import axios from 'axios';

function BookAppointment() {
  const [doctorId, setDoctorId] = useState('');
  const [date, setDate] = useState('');

  const book = async () => {
    await axios.post('http://localhost:5000/api/appointments', {
      patientId: '123', doctorId, date
    });
    alert('Appointment booked');
  };

  return (
    <div>
      <h2>Book Appointment</h2>
      <input type="text" placeholder="Doctor ID" onChange={(e) => setDoctorId(e.target.value)} />
      <input type="datetime-local" onChange={(e) => setDate(e.target.value)} />
      <button onClick={book}>Book</button>
    </div>
  );
}

export default BookAppointment;
